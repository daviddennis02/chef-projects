# Assign values to node attributes

node.default['kafka']['broker_id'] = '0'
node.default['kafka']['port'] = '9092'