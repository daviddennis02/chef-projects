#
# Cookbook:: hadoop_cluster
# Recipe:: default
#
# Copyright:: 2024, The Authors, All Rights Reserved.
