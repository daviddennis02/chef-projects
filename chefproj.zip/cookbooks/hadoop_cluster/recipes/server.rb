#
# Cookbook:: hadoop-cluster
# Recipe:: default
#
# Copyright:: 2024, The Authors, All Rights Reserved.

# Install Java
apt_update 'update' do
  action :update
end

package 'openjdk-11-jdk' do
  action :install
end

# Install hadoop
hadoop_cluster_home = '/opt/hadoop'
hadoop_envfile = '/opt/hadoop/etc/hadoop/hadoop-env.sh'
hadoop_data_dir = '/opt/hadoop/hdfs/data'
hadoop_version = '3.3.6'

user 'hadoop' do
    comment 'hadoop User'
    system true
    shell '/bin/false'
end
  
  group 'hadoop' do
    members 'hadoop'
    system true
    append true
  end
  
  directory hadoop_cluster_home do
    owner 'hadoop'
    group 'hadoop'
    mode '0755'
    action :create
  end

# Download hadoop
remote_file "#{hadoop_cluster_home}/hadoop.tgz" do
  source "https://dlcdn.apache.org/hadoop/common/hadoop-#{hadoop_version}/hadoop-#{hadoop_version}.tar.gz"
  owner 'hadoop'
  group 'hadoop'
  mode '0644'
  action :create
  notifies :run, 'execute[extract_hadoop]', :immediately
end

# Untar hadoop zipped file
execute 'extract_hadoop' do
  command "tar -xzf #{hadoop_cluster_home}/hadoop.tgz -C #{hadoop_cluster_home} --strip-components=1"
  action :nothing
  notifies :run, 'execute[java_home_export]', :immediately
end

# Update the JAVA_HOME in the hadoop_env.sh file
execute 'java_home_export' do
  command "echo export JAVA_HOME=/usr/lib/jvm/java-11-openjdk-amd64/ >> #{hadoop_envfile}"
  action :nothing
end

# Update Hadoop Environment Configuration in the hadoop_env.sh file
bash 'hadoop_config_env_update' do
  user 'hadoop'
  cwd "#{hadoop_cluster_home}"
  code <<-EOH
    echo 'export HDFS_NAMENODE_USER="hadoop"
    export HDFS_DATANODE_USER="hadoop"
    export HDFS_SECONDARYNAMENODE_USER="hadoop"
    export YARN_RESOURCEMANAGER_USER="hadoop"
    export YARN_NODEMANAGER_USER="hadoop"' >> #{hadoop_envfile}
    source #{hadoop_envfile}
  EOH
end

# Create a data directory for the Hadoop Distributed File System (HDFS) 
# to store all relevant HDFS files
directory hadoop_data_dir do
  owner hadoop
  group hadoop
  mode '0755'
  recursive true
  action :create
end

# TODO write the ssh configuration part

# Create xml configuration file

# Update the core-site.xml file for all nodes
template "#{hadoop_cluster_home}/etc/hadoop/core-site.xml" do
  source 'core-site.xml.erb'
  owner hadoop
  group hadoop
  mode 0644
  variables(
    :server_ipaddress => node['ipaddress']
  )
end

# Master node configuration setup
# Update the hdfs-site.xml file for the master node
template "#{hadoop_cluster_home}/etc/hadoop/hdfs-site.xml" do
  source 'hdfs-site-master.xml.erb'
  owner hadoop
  group hadoop
  mode 0644
  variables(
    :hadoop_data_dir => "#{hadoop_data_dir}"
  )
end

# Update the mapred-site.xml file for the master node
template "#{hadoop_cluster_home}/etc/hadoop/mapred-site.xml" do
  source 'mapred-site.xml.erb'
  owner hadoop
  group hadoop
  mode 0644
  # variables(
  #   :server_ipaddress => node['ipaddress'] # should be the hadoop-master-server-ip
  # )
end

# Update the yarn-site.xml file for the master node
template "#{hadoop_cluster_home}/etc/hadoop/yarn-site.xml" do
  source 'yarn-site.xml.erb'
  owner hadoop
  group hadoop
  mode 0644
  # variables(
  #   :server_ipaddress => node['ipaddress'] # should be the hadoop-master-server-ip
  # )
end

# Configure hadoop's point of reference - masters
template "#{hadoop_cluster_home}/etc/hadoop/masters" do
  source 'masters.erb'
  owner hadoop
  group hadoop
  mode 0644
end

# Worker node configuration setup
# Update the hdfs-site.xml file for the worker node
template "#{hadoop_cluster_home}/etc/hadoop/hdfs-site.xml" do
  source 'hdfs-site-master.xml.erb'
  owner hadoop
  group hadoop
  mode 0644
  variables(
    :hadoop_data_dir => "#{hadoop_data_dir}"
  )
end

# Configure hadoop's point of reference - workers
template "#{hadoop_cluster_home}/etc/hadoop/workers" do
  source 'workers.erb'
  owner hadoop
  group hadoop
  mode 0644
end

# In your recipe or cookbook
if node['hostname'] == 'node3' || node['role'] == 'special_node'
  # Configuration specific to node3 or nodes with the 'special_node' role
  # Your configuration code here
else
  # Configuration for other nodes
  # Your default configuration code here
end

# Run the Hadoop Cluster [Run the below tasks on the master node]
# Format the hdfs from the master node
execute 'format_hdfs' do
  command "sudo #{hadoop_cluster_home}/bin/hdfs namenode -format"
  action :nothing
end

# Start the Hadoop cluster by running the following scripts 
# Start the dfs daemon
execute 'start_dfs_daemon' do
  command "sudo #{hadoop_cluster_home}/sbin/start-dfs.sh"
  notifies :write, 'log[debug_start_dfs_message]', :immediately
end

# Output the result
log 'debug_start_dfs_message' do
  message lazy { "Debug information: DFS daemon logs" }
  level :debug
  action :nothing
end

# Start the yarn daemon
execute 'start_yarn_daemon' do
  command "sudo #{hadoop_cluster_home}/sbin/start-yarn.sh"
  notifies :write, 'log[debug_start_yarn_message]', :immediately
end

# Output the result
log 'debug_start_yarn_message' do
  message lazy { "Debug information: Yarn daemon logs" }
  level :debug
  action :nothing
end

# Test hadoop cluster is up
bash 'test_hadoop_cluster' do
  cwd "#{hadoop_cluster_home}/"
  user 'hadoop'
  group 'hadoop'
  code <<-EOH
    curl -X GET 'http://#{hadoop_master_server_ip}:9870'
  EOH
  environment 'hadoop_master_server_ip' => node[master]['ipaddress']
  notifies :write, 'log[debug_hadoop_up]', :immediately
end

# Output the result
log 'debug_hadoop_up' do
  message lazy { "Debug information: HTTP Response" }
  level :debug
  action :nothing
end