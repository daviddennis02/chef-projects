#
# Cookbook:: hadoop 
# Recipe:: default
#
# Copyright:: 2024, The Authors, All Rights Reserved.
include_recipe 'hadoop::server'