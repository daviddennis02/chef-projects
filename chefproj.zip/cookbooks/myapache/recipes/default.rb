#
# Cookbook:: myapache
# Recipe:: default
#
# Copyright:: 2024, The Authors, All Rights Reserved.
include_recipe 'myapache::server'